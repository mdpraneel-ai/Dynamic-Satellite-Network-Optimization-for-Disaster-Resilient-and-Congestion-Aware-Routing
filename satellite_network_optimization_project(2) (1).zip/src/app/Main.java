package app;

import algo.CongestionAwarePlanner;
import algo.DijkstraPlanner;
import algo.HybridRecoveryPlanner;
import algo.RoutePlanner;
import model.Graph;
import model.RouteResult;
import sim.*;
import util.BenchmarkRecord;
import util.CsvExporter;
import util.MetricsCollector;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main {

    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            runDemo();
            return;
        }

        switch (args[0].toLowerCase()) {
            case "demo":
                runDemo();
                break;
            case "benchmark":
                String out = args.length > 1 ? args[1] : "results.csv";
                runBenchmark(out);
                break;
            case "validate":
                runValidation();
                break;
            default:
                System.out.println("Usage:");
                System.out.println("  java app.Main demo");
                System.out.println("  java app.Main benchmark results.csv");
                System.out.println("  java app.Main validate");
        }
    }

    private static void runDemo() {
        int satellites = 12;
        int groundStations = 2;
        int extraEdges = 14;
        long seed = 42L;

        TopologyGenerator generator = new TopologyGenerator(seed);
        Graph graph = generator.generate(satellites, groundStations, extraEdges);
        generator.assignCongestion(graph, 0.65);

        FailureSimulator failureSimulator = new FailureSimulator(seed + 1);
        failureSimulator.applyStaticFailures(graph, 0.08, 0.06);

        int source = satellites;
        int destination = satellites + 1;

        RoutePlanner dijkstra = new DijkstraPlanner();
        RoutePlanner congestion = new CongestionAwarePlanner(0.8, 0.7);
        RoutePlanner hybrid = new HybridRecoveryPlanner(0.8, 0.7, 0.30, seed + 2);

        List<RoutePlanner> planners = List.of(dijkstra, congestion, hybrid);

        System.out.println("Satellite Network Optimization Demo");
        System.out.println("Source: " + source + "  Destination: " + destination);

        for (RoutePlanner planner : planners) {
            Graph copy = new Graph(graph);
            RouteResult initial = planner.findRoute(new Graph(copy), source, destination);
            List<FailureEvent> events = failureSimulator.createDynamicFailureSchedule(copy, initial.getPath(), 1.0);
            RouteResult result = TraversalSimulator.executeWithDynamicFailures(copy, planner, source, destination, events);
            printResult(result, copy);
        }
    }

    private static void runBenchmark(String outputCsv) throws IOException {
        long seed = 100L;
        TopologyGenerator generator = new TopologyGenerator(seed);
        FailureSimulator failureSimulator = new FailureSimulator(seed + 7);

        List<RouteResult> aggregateResults = new ArrayList<>();
        List<BenchmarkRecord> records = new ArrayList<>();

        int[] nodeSizes = {20, 50, 100, 200};
        double[] failureRates = {0.00, 0.05, 0.10, 0.20};
        double[] congestionLevels = {0.25, 0.50, 0.75};

        RoutePlanner dijkstra = new DijkstraPlanner();
        RoutePlanner congestion = new CongestionAwarePlanner(0.8, 0.8);
        RoutePlanner hybrid = new HybridRecoveryPlanner(0.8, 0.8, 0.25, seed + 9);

        for (int nodes : nodeSizes) {
            for (double failureRate : failureRates) {
                for (double congestionLevel : congestionLevels) {
                    int satellites = nodes - 2;
                    int groundStations = 2;
                    int extraEdges = Math.max(3, nodes / 2);

                    Graph graph = generator.generate(satellites, groundStations, extraEdges);
                    generator.assignCongestion(graph, congestionLevel);
                    failureSimulator.applyStaticFailures(graph, failureRate, failureRate * 0.8);

                    int source = satellites;
                    int destination = satellites + 1;
                    int edgeCount = graph.countDirectedEdges();

                    Graph c1 = new Graph(graph);
                    Graph c2 = new Graph(graph);
                    Graph c3 = new Graph(graph);

                    RouteResult baseDijkstra = dijkstra.findRoute(new Graph(c1), source, destination);
                    RouteResult baseCongestion = congestion.findRoute(new Graph(c2), source, destination);
                    RouteResult baseHybrid = hybrid.findRoute(new Graph(c3), source, destination);

                    List<FailureEvent> e1 = failureSimulator.createDynamicFailureSchedule(c1, baseDijkstra.getPath(), 1.0);
                    List<FailureEvent> e2 = failureSimulator.createDynamicFailureSchedule(c2, baseCongestion.getPath(), 1.0);
                    List<FailureEvent> e3 = failureSimulator.createDynamicFailureSchedule(c3, baseHybrid.getPath(), 1.0);

                    RouteResult r1 = TraversalSimulator.executeWithDynamicFailures(c1, dijkstra, source, destination, e1);
                    RouteResult r2 = TraversalSimulator.executeWithDynamicFailures(c2, congestion, source, destination, e2);
                    RouteResult r3 = TraversalSimulator.executeWithDynamicFailures(c3, hybrid, source, destination, e3);

                    aggregateResults.add(r1);
                    aggregateResults.add(r2);
                    aggregateResults.add(r3);

                    records.add(new BenchmarkRecord(dijkstra.getName(), nodes, edgeCount, failureRate, congestionLevel, r1));
                    records.add(new BenchmarkRecord(congestion.getName(), nodes, edgeCount, failureRate, congestionLevel, r2));
                    records.add(new BenchmarkRecord(hybrid.getName(), nodes, edgeCount, failureRate, congestionLevel, r3));
                }
            }
        }

        CsvExporter.exportBenchmarks(outputCsv, records);
        System.out.println("Benchmark CSV written to: " + outputCsv);

        MetricsCollector.Summary s1 = MetricsCollector.summarize("Dijkstra", filterByAlgorithm(aggregateResults, "Dijkstra"));
        MetricsCollector.Summary s2 = MetricsCollector.summarize("CongestionAware", filterByAlgorithm(aggregateResults, "CongestionAware"));
        MetricsCollector.Summary s3 = MetricsCollector.summarize("HybridRecovery", filterByAlgorithm(aggregateResults, "HybridRecovery"));

        printSummary(s1);
        printSummary(s2);
        printSummary(s3);
    }

    private static List<RouteResult> filterByAlgorithm(List<RouteResult> all, String name) {
        List<RouteResult> out = new ArrayList<>();
        for (RouteResult r : all) {
            if (r.getAlgorithm().equals(name)) {
                out.add(r);
            }
        }
        return out;
    }

    private static void runValidation() {
        TopologyGenerator generator = new TopologyGenerator(7L);
        Graph graph = generator.generate(6, 2, 5);
        generator.assignCongestion(graph, 0.4);

        RoutePlanner planner = new DijkstraPlanner();
        RouteResult result = planner.findRoute(new Graph(graph), 6, 7);
        boolean pathValid = graph.isValidPath(result.getPath());
        double recomputedCost = graph.computePathCost(result.getPath());

        System.out.println("Validation run");
        System.out.println("Path valid: " + pathValid);
        System.out.println("Planner cost: " + result.getTotalCost());
        System.out.println("Recomputed cost: " + recomputedCost);
        System.out.println("Match: " + (Math.abs(result.getTotalCost() - recomputedCost) < 1e-6));
    }

    private static void printResult(RouteResult result, Graph graph) {
        System.out.println("Algorithm: " + result.getAlgorithm());
        System.out.println("Success: " + result.isSuccess());
        System.out.println("Runtime(ms): " + result.getRuntimeMs());
        System.out.println("Cost: " + result.getTotalCost());
        System.out.println("Reroutes: " + result.getRerouteCount());
        System.out.println("Path: " + result.getPath());
        System.out.println("Path valid: " + graph.isValidPath(result.getPath()));
        System.out.println("Notes: " + result.getNotes());
        System.out.println();
    }

    private static void printSummary(MetricsCollector.Summary s) {
        System.out.println("=== " + s.algorithm + " Summary ===");
        System.out.println("Runs: " + s.runs);
        System.out.println("Avg runtime(ms): " + String.format("%.2f", s.avgRuntime));
        System.out.println("Avg cost: " + String.format("%.2f", s.avgCost));
        System.out.println("Success rate: " + String.format("%.2f", s.successRate * 100) + "%");
        System.out.println("Avg hops: " + String.format("%.2f", s.avgHops));
        System.out.println("Avg reroutes: " + String.format("%.2f", s.avgReroutes));
        System.out.println();
    }
}
